package vn.vonhan.privateai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE32636)
private val White = Color(0xFFF5F5F5)

class MainActivity : ComponentActivity() {
    private val prefs by lazy {
        val key = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(this, "vonhan_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, background = Black, surface = Panel,
                onBackground = White, onSurface = White
            )) {
                var unlocked by remember { mutableStateOf(false) }
                var showSettings by remember { mutableStateOf(false) }
                if (!unlocked) {
                    LoginScreen(onUnlock = { entered ->
                        // So sánh băm; không lưu mật khẩu dạng văn bản.
                        unlocked = secureHash(entered) == LOGIN_HASH
                    })
                } else if (showSettings) {
                    SettingsScreen(
                        current = prefs.getString("api_key", "") ?: "",
                        onSave = { prefs.edit().putString("api_key", it.trim()).apply(); showSettings = false },
                        onBack = { showSettings = false }
                    )
                } else {
                    ChatScreen(
                        apiKey = prefs.getString("api_key", "") ?: "",
                        onSettings = { showSettings = true }
                    )
                }
            }
        }
    }
}

private fun secureHash(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(("vonhan-private-salt-2026:" + s).toByteArray())
        .joinToString("") { "%02x".format(it) }

// Giá trị băm của mật khẩu do chủ app chọn trong lần thiết lập ban đầu.
private const val LOGIN_HASH = "f7bf0c7f3dbc48dc4c4e5f8dc3a9929d2de4756e9ee2ca3ec08cce2c21ceb46c"

@Composable
private fun LoginScreen(onUnlock: (String) -> Unit) {
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Black).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("VÔ NHÂN 㐅", color = Red, style = MaterialTheme.typography.headlineLarge)
        Text("TRỢ LÝ RIÊNG TƯ", color = White)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(pass, { pass = it; error = false }, label = { Text("Mật khẩu ứng dụng") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true)
        if (error) Text("Mật khẩu không đúng", color = Red)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { val ok = secureHash(pass) == LOGIN_HASH; error = !ok; if (ok) onUnlock(pass) },
            colors = ButtonDefaults.buttonColors(containerColor = Red), modifier = Modifier.fillMaxWidth()) {
            Text("MỞ KHÓA")
        }
    }
}

data class ChatLine(val text: String, val mine: Boolean)

@Composable
private fun ChatScreen(apiKey: String, onSettings: () -> Unit) {
    val scope = rememberCoroutineScope()
    val lines = remember { mutableStateListOf(ChatLine("Tao là VÔ NHÂN 㐅. Có gì nói thẳng.", false)) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Black).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("VÔ NHÂN 㐅", color = Red, style = MaterialTheme.typography.titleLarge)
                Text("AI RIÊNG CỦA BẠN", color = White, style = MaterialTheme.typography.labelSmall)
            }
            TextButton(onClick = onSettings) { Text("CÀI ĐẶT", color = Red) }
        }
        HorizontalDivider(color = Red.copy(alpha = .5f))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(lines) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement =
                    if (line.mine) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (line.mine) Color(0xFF542027) else Panel,
                        shape = RoundedCornerShape(14.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                        Text(line.text, color = White, modifier = Modifier.padding(12.dp))
                    }
                }
            }
        }
        if (busy) Text("Đang suy nghĩ…", color = Red)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Nhập tin nhắn…") }, maxLines = 4)
            IconButton(onClick = {
                val msg = input.trim()
                if (msg.isNotEmpty() && !busy) {
                    input = ""; lines.add(ChatLine(msg, true))
                    if (apiKey.isBlank()) {
                        lines.add(ChatLine("Mở CÀI ĐẶT và nhập khóa API để kết nối AI trực tuyến.", false))
                    } else {
                        busy = true
                        scope.launch {
                            val answer = withContext(Dispatchers.IO) { askAi(apiKey, lines.toList()) }
                            lines.add(ChatLine(answer, false)); busy = false
                        }
                    }
                }
            }) { Icon(Icons.Default.Send, contentDescription = "Gửi", tint = Red) }
        }
    }
}

@Composable
private fun SettingsScreen(current: String, onSave: (String) -> Unit, onBack: () -> Unit) {
    var key by remember { mutableStateOf(current) }
    Column(Modifier.fillMaxSize().background(Black).padding(20.dp)) {
        Text("CÀI ĐẶT AI", color = Red, style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(18.dp))
        Text("Khóa API", color = White)
        OutlinedTextField(key, { key = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Dán khóa API tại đây") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(8.dp))
        Text("Khóa được lưu mã hóa trên thiết bị. Không chia sẻ APK có chứa khóa của bạn.",
            color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(20.dp))
        Button(onClick = { onSave(key) }, colors = ButtonDefaults.buttonColors(containerColor = Red),
            modifier = Modifier.fillMaxWidth()) { Text("LƯU CÀI ĐẶT") }
        TextButton(onClick = onBack) { Text("QUAY LẠI", color = White) }
    }
}

private fun askAi(apiKey: String, lines: List<ChatLine>): String {
    return try {
        val client = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content",
            "Bạn là VÔ NHÂN 㐅, trợ lý nói tiếng Việt. Phong cách lạnh lùng, thẳng thắn, hài hước và cà khịa vừa phải; vẫn tôn trọng an toàn, không hỗ trợ gây hại. Trả lời tự nhiên, hữu ích."))
        lines.takeLast(20).forEach {
            messages.put(JSONObject().put("role", if (it.mine) "user" else "assistant").put("content", it.text))
        }
        val body = JSONObject().put("model", "gpt-4o-mini").put("messages", messages)
            .put("temperature", 0.8).toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey").post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) "Lỗi kết nối (${response.code}). Kiểm tra khóa API và hạn mức thanh toán."
            else JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
    } catch (e: Exception) {
        "Không kết nối được AI: ${e.message ?: "lỗi không xác định"}"
    }
}

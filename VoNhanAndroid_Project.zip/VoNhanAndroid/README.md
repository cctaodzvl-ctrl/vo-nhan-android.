# VÔ NHÂN 㐅 — dự án Android

## Tình trạng
Đây là mã nguồn Android Studio, chưa phải APK đã biên dịch. Môi trường tạo tệp hiện tại không có Android SDK/Gradle để xuất APK.

## Mở và tạo APK
1. Cài Android Studio trên máy tính.
2. Giải nén dự án và chọn Open, trỏ tới thư mục `VoNhanAndroid`.
3. Chờ Gradle Sync hoàn tất.
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Kết nối AI trực tuyến
1. Tạo khóa API trong tài khoản OpenAI Platform và bật thanh toán nếu cần.
2. Mở app > Cài đặt AI > dán khóa API > Lưu cài đặt.
3. Khóa được lưu bằng EncryptedSharedPreferences trên thiết bị. Không chia sẻ khóa hoặc APK đã cấu hình.

## Riêng tư
- App có màn hình khóa riêng. Mật khẩu ban đầu được kiểm tra bằng mã băm, không lưu dạng văn bản.
- Đây là khóa cục bộ trên một bản cài đặt, không phải xác thực máy chủ; người có thể sửa APK có thể vượt qua. Muốn bảo vệ thật sự nhiều thiết bị cần máy chủ đăng nhập và giới hạn tài khoản.
- Chat gọi API trực tiếp từ điện thoại; nhà cung cấp API có thể tính phí theo mức sử dụng.
- Bản mẫu chỉ giữ hội thoại trong bộ nhớ khi app đang mở; chưa đồng bộ/backup lịch sử.
